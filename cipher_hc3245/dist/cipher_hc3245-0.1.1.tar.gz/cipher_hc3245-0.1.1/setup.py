# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['cipher_hc3245']
setup_kwargs = {
    'name': 'cipher-hc3245',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Hongbin Chen',
    'author_email': 'hc3245@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
